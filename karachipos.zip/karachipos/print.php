<?php
require __DIR__ . '/print/autoload.php';
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\CapabilityProfiles\StarCapabilityProfile;
use Mike42\Escpos\EscposImage;

try {
    $connector = null;
    $connector = new WindowsPrintConnector("karachipos");
	$profile = StarCapabilityProfile::getInstance();
	$printer = new Printer($connector, $profile);
	//$printer = new Printer($connector);
	$text = $_POST['data']."\n";
    $duplicate = $_POST['dupl'];
	$printer -> setJustification(Printer::JUSTIFY_CENTER);
	$myCoolCommand = "\x09";
	$myCoolCommand1 = "\x0a";
	$text_new = explode("|",$text);
    $bag = $_POST['bags'];
    $img = EscposImage::load('./images/KarachiBakery_Logo.png');
	$printer -> bitImage($img);
	$printer -> text($myCoolCommand1);
	$printer -> text("KARACHI BAKERY\n");
	$head = $_POST['header'];
	$text_head = explode("|",$head);
	foreach($text_head as $text_head_data)
	{
		$printer -> text($text_head_data."\n");
	}
    $printer -> selectPrintMode(Printer::MODE_EMPHASIZED);
    $printer -> text("Sales Invoice\n");
    $printer -> selectPrintMode();
    $printer -> text("------------------------------------------\n");
	$printer -> setJustification(Printer::JUSTIFY_LEFT);
	foreach($text_new as $newtext){
		$tabs = explode("//",$newtext);
		foreach($tabs as $tabdata)
		{
			$printer -> text($tabdata);
			$connector -> write($myCoolCommand);
		}
		$printer -> text($myCoolCommand1);
	}
    $text_dup = explode("|",$duplicate);
    foreach($text_dup as $text_dup_data)
	{
        //$printer -> text($text_dup_data."\n");
        //$printer -> text($myCoolCommand1);
    }
    $printer -> setJustification(Printer::JUSTIFY_LEFT);
    $printer -> selectPrintMode(Printer::MODE_EMPHASIZED);
    $printer -> setTextSize(2,2);
    $text_bag = explode("|",$bag);
    foreach($text_bag as $text_bag_data)
	{
		$printer -> text($text_bag_data."\n");
        $printer -> text($myCoolCommand1);
	}
    $printer -> selectPrintMode();
    $printer -> setTextSize(1,1);
	$printer -> setJustification(Printer::JUSTIFY_CENTER);
	$printer -> text("------------------------------------------\n NO RETURN _ NO EXCHANGE \n------------------------------------------\n");
	$printer -> text ("\n \n");
    $printer -> cut();
    $printer -> close();
     
    if($text_dup_data == "true"){
            try{
                $connector = null;
                $connector = new WindowsPrintConnector("karachipos");
                $profile = StarCapabilityProfile::getInstance();
                $printer = new Printer($connector, $profile);
                //$printer = new Printer($connector);
                $text = $_POST['data']."\n";
                $printer -> setJustification(Printer::JUSTIFY_CENTER);
                $myCoolCommand = "\x09";
                $myCoolCommand1 = "\x0a";
                $text_new = explode("|",$text);
                $bag = $_POST['bags'];
                $img = EscposImage::load('./images/KarachiBakery_Logo.png');
                $printer -> bitImage($img);
                $printer -> text($myCoolCommand1);
                $printer -> text("KARACHI BAKERY\n");
                $head = $_POST['header'];
                $text_head = explode("|",$head);
                foreach($text_head as $text_head_data)
                {
                    $printer -> text($text_head_data."\n");
                }
                $printer -> selectPrintMode(Printer::MODE_EMPHASIZED);
                $printer -> text("Gate Pass\n");
                $printer -> selectPrintMode();
                $printer -> text("------------------------------------------\n");        
                $printer -> setJustification(Printer::JUSTIFY_LEFT);
                foreach($text_new as $newtext){
                    $tabs = explode("//",$newtext);
                    foreach($tabs as $tabdata)
                    {
                        $printer -> text($tabdata);
                        $connector -> write($myCoolCommand);
                    }
                    $printer -> text($myCoolCommand1);
                }
                $printer -> setJustification(Printer::JUSTIFY_LEFT);
                $printer -> selectPrintMode(Printer::MODE_EMPHASIZED);
                $printer -> setTextSize(2,2);
                $text_bag = explode("|",$bag);
                foreach($text_bag as $text_bag_data)
                {
                    $printer -> text($text_bag_data."\n");
                    $printer -> text($myCoolCommand1);
                }
                $printer -> selectPrintMode();
                $printer -> setTextSize(1,1);
                $printer -> setJustification(Printer::JUSTIFY_CENTER);
                $printer -> text("------------------------------------------\n NO RETURN _ NO EXCHANGE \n------------------------------------------\n");
                $printer -> text ("\n \n");
                $printer -> cut();
                $printer -> close();
            }catch (Exception $e1) {
            echo "Couldn't print to this printer: " . $e -> getMessage() . "\n";
          } 
         
}}else{
catch (Exception $e) {
            echo "Couldn't print to this printer: " . $e -> getMessage() . "\n";
        }}

