<?php
header('Location:../');

?>