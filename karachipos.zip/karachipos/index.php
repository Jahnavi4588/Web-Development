<?php
include "./header.php";
if(isset($_POST['firstname']))
{
	$X=$_POST['firstname']; 
	$Y=$_POST['password'];
	$url = $POS_URL . "ADUser?l=$X&p=$Y&_where=username=%27$X%27%20and%20password!=null%20and%20defaultRole!=null&_startRow=0&_endRow=1";
	function get_http_response_code($url)
	{
		$headers = get_headers($url);
		return substr($headers[0], 9, 3);
	}
	if(get_http_response_code($url) != "200")
	{
		echo "<center><font color='red'> Username or Password is wrong!!</font></center>";
		header( "refresh:2; url=".$BASE_URL );	
	}
	else
	{
		if(isset($_SESSION['username'])){unset($_SESSION['username']);}
		if(isset($_SESSION['password'])){unset($_SESSION['password']);}
		$_SESSION['username']= $X;
		$_SESSION['password']= $Y;
		$url2=json_decode(file_get_contents($POS_URL . "ADUser?l=$X&p=$Y&_where=username=%27$X%27%20and%20password!=null%20and%20defaultRole!=null&_startRow=0&_endRow=1"),true)['response']['data'][0];
		$org_id=$url2['organization'];
		$warehouse_id=json_decode(file_get_contents($POS_URL . "Warehouse?l=$X&p=$Y&_where=organization=%27$org_id%27"),true)['response']['data'][0]['id'];
		$org_info_web_service=json_decode(file_get_contents($POS_URL . "OrganizationInformation?l=$X&p=$Y&_where=organization=%27$org_id%27&_selectedProperties=locationAddress,taxID"),true)['response']['data'][0];
		$docTypeId=json_decode(file_get_contents($POS_URL . "DocumentType?l=$X&p=$Y&_selectedProperties=id,organization,name&_where=organization=%27$org_id%27%20and%20name=%27POS%20Order%27"),true)['response']['data'][0]['id'];
		$storename=json_decode(file_get_contents($POS_URL . "Organization?l=$X&p=$Y&_where=id=%27$org_id%27"),true)['response']['data'][0]['description'];
		$_SESSION['storeName']=$storename;
		$_SESSION['userid']=$url2['id'];
		$_SESSION['clientid']=$url2['client'];
		$_SESSION['orgid']=$url2['organization'];
		$_SESSION['bp_name']=$url2['businessPartner$_identifier'];
		$_SESSION['bp_addr']=$url2['partnerAddress$_identifier'];
		$_SESSION['bp_id']=$url2['businessPartner'];
		$_SESSION['bp_add_id']=$url2['partnerAddress'];
		$_SESSION['tax_id'] = $org_info_web_service['taxID'];
		$_SESSION['docTypeId']=$docTypeId;
		$_SESSION['whereid']=$warehouse_id;
		$_SESSION['storeaddr']=$org_info_web_service['locationAddress$_identifier'];
		header("Location:".$BASE_URL);
		echo "<br>Warehouse id => ".$warehouse_id."<br />Store Addr".$store_add;
		echo "welcome  ".$_SESSION['username'].$_SESSION['password'];
	}
}
else{
	if(isset($_SESSION['username']))
		{
			$url = $BASE_URL."index1.php";
			header("Location:$url");
		}
		else
		{
?>
			<html>
			<head><link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
			<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
			<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
			</head>
			<style>
			body {
			    background-color: white;
			}
			#loginbox {
			    margin-top: 30px;
			}
			#loginbox > div:first-child {        
			    padding-bottom: 10px;    
			}
			.iconmelon {
			    display: block;
			    margin: auto;
			}
			#form > div {
			    margin-bottom: 25px;
			}
			#form > div:last-child {
			    margin-top: 10px;
			    margin-bottom: 10px;
			}
			.panel {    
			    background-color: transparent;
			}
			.panel-body {
			    padding-top: 30px;
			    background-color: rgba(2555,255,255,.3);
			}
			#particles {
			    width: 100%;
			    height: 100%;
			    overflow: hidden;
			    top: 0;                        
			    bottom: 0;
			    left: 0;
			    right: 0;
			    position: absolute;
			    z-index: -2;
			}
			.iconmelon,
			.im {
			  position: relative;
			  width: 150px;
			  height: 150px;
			  display: block;
			  fill: #525151;
			}
			.iconmelon:after,
			.im:after {
			  content: '';
			  position: absolute;
			  top: 0;
			  left: 0;
			  width: 100%;
			  height: 100%;
			}
			#logo{
				width:50%;
				height:auto;
			}
			</style>
			<body>
				<div class="container">          
				    <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3"> 
				  		<div class="panel panel-default" >
				            <div class="panel-heading">
				                <div class="panel-title text-center">Karachi POS Login</div>
				            </div>
				            <div class="panel-body" >
								<center><img src="./images/KarachiBakery_Logo.png" class="img-responsive" id="logo"></center><br><br><br><br>
				                <form name="form" id="form" class="form-horizontal" enctype="multipart/form-data" method="POST" action="index.php">
				                    <div class="input-group">
				                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
				                        <input id="user" type="text" class="form-control" name="firstname" value="" placeholder="Username">
				                    </div>
				                    <div class="input-group">
				                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
				                        <input id="password" type="password" class="form-control" name="password" placeholder="Password">
				                    </div>                                                                  
				                    <div class="form-group">
				                        <!-- Button -->
				                        <div class="col-sm-12 controls">
				                            <button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Log in</button>                          
				                        </div>
				                    </div>
				                </form>     
				            </div>                     
				        </div>  
				    </div>
				</div>
			</body></html><?php
		}
	}
?>
