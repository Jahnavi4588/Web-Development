<?php include "./header.php"; ?>
<script>
        function GetTimeandDatefun(){
                var date = new Date();
                $("#timeanddate").html(date);
        }
        $(document).ready(function(){ setInterval(GetTimeandDatefun, 1000);});
</script>
<div id="timeanddate"></div>
