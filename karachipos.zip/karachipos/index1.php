<?php
include "./header.php";
if(empty($_SESSION['username']))
	{
		header("Location:".$BASE_URL);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<style>
		#timeanddate{
                        text-align:right;i.deleteorder').click(function(e) 
                }
		* {
		    box-sizing: border-box;
		    font-size: 14px;
		}
		input[type=text], select{
		    width: 100%;
		    padding: 12px;
		    border: 1px solid #ccc;
		    border-radius: 4px;
		    resize: vertical;
		}
		label {
		    padding: 12px 12px 12px 0;
		    display: inline-block;
		}
		input[type=submit] {
		    background-color: #6cb33f;
		    color: white;
		    padding: 12px 20px;
		    border: none;
		    border-radius: 4px;
		    cursor: pointer;
		    float: right;
		}
		input[type=submit]:hover {
		    background-color: #42c8f4;
		}
        #type1 {
            background-color: #DDDD;
            padding: 12px 12px 12px 12px;
            float:inherit;
            width: 200px;        }
        
		.container {
		    border-radius: 5px;
		    background-color: #f2f2f2;
		    padding: 20px;
		    width:50%;
		    margin:auto;
		}
        
        /*p
        {
            font-size: 14px;
        }*/
		.col-25 {
		    float: left;
		    width: 25%;
		    margin-top: 6px;
		}
		.col-75 {
		    float: left;
		    width: 75%;
		    margin-top: 6px;
		}
		.row:after {
		    content: "";
		    display: table;
		    clear: both;
		}
		@media screen and (max-width: 600px) {
		    .col-25, .col-75, input[type=submit],.container {
		        width: 100%;
		        margin-top: 0;
		    }
		}
		@page,body {
		   size: 7in 9.25in;
		   margin: 27mm 16mm 27mm 16mm;
		}
		body{
			background-color: #2c2626;
			color: white;
			font-size: 18px;
		}
		.row .col-6 > ul > li{
			background-color: #6cb33f;
		}
		.row .col-6 > ul > li > a{
			color: white;	
		}
		h3 {
		    text-align: center;
		}
		.bootstrap-select {
		    width: 100% !important;
		}
		#bpCreation input,#bpCreation select,{
			width:80%;
			margin:auto;
		}
		#printbutton2:hover,#deleteorder1:hover{
			cursor: pointer;
		}
	</style>
</head>
<body onload="printvalue()">
	<div class="container-fluid" style="width:92%;">
		<div class="row" style="height: 25px;"> </div>
			<div class="row">
				<div class="col-6">
					<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist" style="line-height: 45px;text-align: center;">
					  <li class="nav-item" style="width: 18%;" id="printbutton2">
					    <a class="nav-link"data-toggle="pill" role="tab" style="height:60px;">Summary</a></li>
					  <li class="nav-item" style="width: 18%;margin-left: 2%;">
					 <a  href="<?php echo $BASE_URL.'bill.php';?>" style="height:60px;">Bill List</a>
					  </li>
					  <li class="nav-item deleteorder" style="width: 14%;margin-left: 2%;" id="deleteorder">
					    <a class="nav-link"data-toggle="pill" role="tab" style="height:60px;" id="deleteorder1"><span class="glyphicon glyphicon-trash"></span></a>
					  </li>                                            
				     <li class="nav-item" style="width: 15.5%;margin-left: 2%;">
					       <a class="nav-link TotalDiscount" data-toggle="pill" href="#pills-last" role="tab" aria-controls="pills-last" aria-selected="true" style="height:60px;"><div data-toggle="modal" data-target="#myModal1" id="totaldiscount">Discount</div></a>
					    </li>                        
                        <li class="nav-item" style="width: 26.5%;margin-left: 2%;">
					       <a class="nav-link TotalPrice" data-toggle="pill" href="#pills-last" role="tab" aria-controls="pills-last" aria-selected="true" style="height:60px;"><div data-toggle="modal" data-target="#myModal" id="totalamount">0.00</div></a>
					  </li>
					</ul>
					<div id="receipt" style="display:none;height:60px;"></div>
					<div class="tab-content" id="pills-tabContent" style="min-height: 600px;max-height: 650px;overflow:auto;background-color: white;color: black;">
					  <div class="tab-pane fade show active" id="pills-last1" role="tabpanel" aria-labelledby="pills-last-tab">
					  	<br>
					  		<div class="row" style="height:50px;width:98%;margin:auto;">
					  			<div class="col-6 bpname" style="padding-left:25px;">
					  				<div  id="dialog" style="display:none;" title="Business Partner Selection" >
										<button id="opener1" style="display: none;">New Customer</button><br><br>
										<button id="bploc1" style="display:none;"><?php echo $_SESSION['bp_add_id'];?></button>
										<button id="bpid1" style="display:none;"><?php echo $_SESSION['bp_id'];?></button>
									</div>
				  					<button id="opener123"><?php echo $_SESSION['username'];?> @ <?php echo $_SESSION['storeName'];?></button>
					  			</div>
					  			<div class="col-6 bpaddr" style="padding-left:25px;text-align: right"><select id="cust_type" onchange="OrderID(this)">                                
                                </select>
                                    <input type="hidden" name="cust_type1" id= "cust_type1" value="" >  
                                    <input type="hidden" name="cust_search" id= "cust_search" value="" >  
                                    <br><br> 
								</div>
					  		</div>
					  		<hr width=94%; style="border: 0; height: 0; border-top: 1px solid rgba(0, 0, 0, 0.3); border-bottom: 1px solid rgba(255, 255, 255, 0.3);">
					  		<div class="row" style="width:98%;margin:auto;">
					  			<div class="col-12 order" id="orderitems" style="padding:5px 25px;"></div>
					  		</div>
					  		<hr width=94%; style="border: 0; height: 0; border-top: 1px solid rgba(0, 0, 0, 0.3); border-bottom: 1px solid rgba(255, 255, 255, 0.3);">
					  		<div class="row" style="width:98%;margin:auto;">
					  			<div class="col-12 taxes" id="taxes" style="padding:5px 25px;"></div>
					  		</div>
					  		<hr width=94%; style="border: 0; height: 0; border-top: 1px solid rgba(0, 0, 0, 0.3); border-bottom: 1px solid rgba(255, 255, 255, 0.3);">
					  		<div class="row" style="width:98%;margin:auto;">
					  			<div class="col-12 taxes" id="taxes" style="padding:5px 25px;"></div>	
					  		</div> 
					  </div>
				</div>
			</div>
			<div class="col-6">
				<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist" style="line-height: 45px;text-align: center;">
				  <li class="nav-item active" style="width: 20%;">
				    <a class="nav-link" id="pills-scan-tab" data-toggle="pill" href="#pills-home1" role="tab" aria-controls="pills-home" aria-selected="true" style="height:60px;" id="scanitem">SCAN</a>
				  </li>
				  <li class="nav-item" id="browse-categories" style="width: 27%;margin-left: 2%;">
				    <a class="nav-link" id="pills-browse-tab" data-toggle="pill" href="#pills-profile1" role="tab" aria-controls="pills-profile" aria-selected="false" style="height:60px;">BROWSE</a>
				  </li>
				  <li class="nav-item" style="width: 27%;margin-left: 2%;">
				    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact1" role="tab" aria-controls="pills-contact" aria-selected="false" style="height:60px;">SEARCH</a>
				  </li>
				  <li class="nav-item" style="width: 20%;margin-left: 2%;" class="logout" id="logout">
				    <a  href="<?php echo $BASE_URL.'/signout.php';?>" style="height:60px;">Off</a>
				  </li>
				</ul>
				<div class="tab-content" id="pills-tabContent" style="min-height:600px;max-height: 650px;overflow:auto;background-color: white;color: black;">
				<div id="timeanddate"> </div>
				<div class="tab-pane fade active in" id="pills-home1" role="tabpanel" aria-labelledby="pills-home1-tab" >
				    <div class="row" style="padding: 0px 15px;width:98%;">
				    	<div class="col-1"></div>
				        <div class="col-10">
				            <h3>Scan Items</h3>
				            <div align="center" class="barcode_search">
							    <input type="text" name="barcode_search" id="barcode_search" placeholder="Start Scanning the products" class="form-control " autofocus="true" />
							   </div>
							   <div class="list barcode-list">
							   <ul class="list-group barcode-list-group" id="barcode-result"></ul>
							   <div id="order"></div>
							 </div>
				        </div>
				    </div>
				  </div>
				  <div class="tab-pane fade" id="pills-profile1" role="tabpanel" aria-labelledby="pills-profile1-tab">
			  		<div class="row" style="padding: 0px 15px;margin:auto;">
			  			<div class="col-6">
			  				<div class="row">
		  						<div class="col-12"><center>Choose Products</center><br></div>
		  					</div>
		  					<div class="row">
			  					<div class="col-12" id="productsDiv"></div>
					  		</div>
					  	</div>
			  			<div class="col-6">
			  				<div class="row">
		  						<div class="col-12"><center>Choose Category</center><br></div>
		  					</div>
		  					<div class="row">
			  					<div class="col-12" id="categoriesDiv"></div>
					  		</div>
					  	</div>
			  		</div>
				  </div>
				  <div class="tab-pane fade" id="pills-contact1" role="tabpanel" aria-labelledby="pills-contact1-tab">
				  	<div class="row">
				  		<div class="col-1"></div>
				        <div class="col-10">
				            <h3>Search for products</h3>
				            <div align="center" class="product_search">
							    <input type="text" name="product_search" id="product_search" placeholder="Start Scanning the products" class="form-control " autofocus="true" />
							   </div>
							   <div class="list bar  code-list">
							   <ul class="list-group product-list-group" id="product-result"></ul>
							 </div>
				        </div>
				  </div>
				</div>                                   
        <!--  <div class="tab-pane fade" id="pills-last" role="tabpanel" aria-labelledby="#pills-last">
				  	<button id="array" style="display: none;"></button>-->
                      
                      <div class="modal" id="myModal1">
                        <div class="modal-dialog">
                          <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                              <h4 class="modal-title">Discount</h4>
                              <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                              </div>
					        <div class="modal-body">
					          <form action="#" method="POST">
                                 <h4> <strong><u>Enter Store Manager Credentials: </u></strong></h4> 
                                <label style="width: 200px;">Username:</label><input type="username" id="user" value="" style="width: 200px;"><br>
                                  <label style="width: 200px;">Password:</label><input type="password" id="pass" value="" style="width: 200px;"><br>
                                  <h4> <strong><u>Enter Discount Percentage: </u></strong></h4> 
                                <label style="width: 200px;">Discount:</label><input type="text" id="discount" value="" style="width: 200px;"><br><br>
					            <input style="margin-right:0px;background-color: #6cb33f;color:black;" type="submit" value="submit" id="submitbutton"><br>
					          </form>
					        </div>
					        <div class="modal-footer">
					          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					        </div>
					      </div>
					    </div>
					  </div>
                  <!--  </div>-->                                          
                <div class="tab-pane fade" id="pills-last" role="tabpanel" aria-labelledby="#pills-last">
				  	<button id="array" style="display: none;"></button>
                      
				  	  <div class="modal" id="myModal">
                        <div class="modal-dialog">
                          <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                              <h4 class="modal-title">Change</h4>
                                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
					        </div>
					        <div id="receipt" style="display: none;">
					        	<button id="header1" style="display: none;"></button>
					        	<button id="data1" style="display: none;"></button>
								<button id="data2" style="display: none;"></button>
								<button id="data3" style="display: none;"></button>
				        		<button id="totalgrand" style="display: none;"></button>
				        		<button id="taxReceipt" style="display: none;"></button>
					        </div>
					        <div class="modal-body">
					          <form action="#" method="POST">
                                 <label id="pa" style="width: 200px">Payment:</label>
                                 <select id="pay_type" style="width: 200px;" selected='selected' onchange="paytype(this)">            </select>								
					            <label style="width: 200px;">Total:</label><input type="text" disabled=disabled id="formtotal" style="width: 200px;"><br>
					            <label style="width: 200px;">Amount Given:</label><input type="text" id="givenamount" value="" style="width: 200px;"><br>
					            <label style="width: 200px;">Need to be returned:</label><input type="text" value="" disabled=disabled id="tobereturn" style="width: 200px;"><br>
						    <label style="width: 200px;">No. of carry bags :</label><input type="text" id="carrybags" name="carrybags" value="1" style="width: 200px;"><br><br>
					            <input style="margin-right:50px;background-color: #6cb33f;color:black;" type="submit" value="Print" id="printbutton"><br>
					          </form>
					        </div>
					        <div class="modal-footer">
					          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					        </div>
					      </div>
					    </div>
					  </div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<script>
     var type_pay;
    var url_payment = "<?php echo $POS_URL; ?>FIN_PaymentMethod?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>"; 
        console.log(url_payment); 
     //alert($("#cust_type1").val() + $("#cust_search").val());
     $.getJSON(url_payment,function(data) 
          {
             var str = ""; 
            $.each(data.response.data, function(key, value){
            
              window.pay_name = value.name;
              window.pay_id = value.id;
                 type_pay=$("#cust_search").val();
                 //alert(type_pay);
                if(value.name.toString()=="CASH")
                    {
                        str = str + "<option value='"+pay_id+"' selected>"+pay_name+"</option>";
                    }
                else{
                    str = str + "<option value='"+pay_id+"'>"+pay_name+"</option>";
                }                   
        });
            $('#pay_type').html(str);
            
          });    
    function paytype(select)
    {
        var ty = pay_type.options[pay_type.selectedIndex].innerHTML;
        window.paymethod = $('#pay_type').val();       
    } 
    
var url_customer = "<?php echo $POS_URL; ?>BusinessPartner?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>";
        console.log(url_customer);
        
    
   var cus_id;
    var cust_searchKey = ""; 
    var pay_terms = "";
    var pay_identifier="";
     var pay_terms_identifier="";
        $.getJSON(url_customer,function(data) 
          {            
            var strng = "";            
            $.each(data.response.data, function(key, value){
              var cust_name = value.name;
                cust_searchKey = value.searchKey;
                pay_terms = value.paymentTerms;
                pay_identifier = value.paymentTerms$_identifier;
                pay_terms_identifier = pay_terms+" "+pay_identifier;
                var cust_id = value.id;
                cus_id=cust_id;
                if(value.searchKey.toString()=="SW1")
                {
                    pay=pay_terms;
               strng = strng + "<option value='"+cust_id+"'selected id='"+cust_searchKey+"' class='"+pay_terms_identifier+"'>"+cust_name+" </option>";
                    $("#cust_type1").val(pay_terms);
                $("#cust_search").val(pay_identifier);
                    
                }
                else if(value.searchKey.toString()=="UE1" || value.searchKey.toString()=="SY1" || value.searchKey.toString()=="Z1"){
             strng = strng + "<option value='"+cust_id+"' id='"+cust_searchKey+"' class='"+pay_terms_identifier+"'>"+cust_name+"</option>";
                }            
                
            });       
          
            $('#cust_type').html(strng);
             var url_cust = "<?php echo $POS_URL; ?>BusinessPartner?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=id="+cus_id+"";
    //console.log(url_cust);
               });
    var des="";
    var pay= "";
    var selectpay="";
    var payname="";
    var carrybags = 0;
 function OrderID(select){
        
        var url_payment1 = "<?php echo $POS_URL; ?>FIN_PaymentMethod?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>"; 
        console.log(url_payment1);
            //$("#cust_type1").val() + $("#cust_search").val());    
                var searchingkey=select[select.selectedIndex].id;
                var id=select[select.selectedIndex].value;
                selectpay=select[select.selectedIndex].className;
                var index = selectpay.indexOf(" ");  // Gets the first index where a space occours
                var id = selectpay.substr(0, index); // Gets the first part
                var text = selectpay.substr(index + 1);
                
                pay=id;
                payname=text;
               // alert("paymentterms:"+pay);
               //alert("paymentterms_identifier:"+payname);               
                $("#cust_type1").val(pay);
                $("#cust_search").val(payname);
                var txt;
                var cust_name=cust_type.options[cust_type.selectedIndex].innerHTML; 
                window.cus_name=cust_name;
                if(searchingkey.toString()!="SW1")
                {
                    var strngg = "";
                    var person = prompt("Please enter your " +cus_name+ " ID:", "Order ID");
                    var desc="#"  +person;
                    des=desc;
                    if (person == null || person == "" || person == "Order ID")
                    {
                        txt = "User didn't enter the Order ID.";
                    }
                    else
                    {
                       txt = "Your Order ID is " + person;
                    }
                    alert(txt);
                    //alert(payname);
                    strngg = strngg + "<option value='"+pay_id+"'>"+payname+"</option>";
                             $('#pay_type').html(strngg);

                }
                else
                {
                    var strngg = "";
                    //alert("URL: "+url_payment1);
                    $.getJSON(url_payment1,function(data) 
                    {   
                    var str = ""; 
                     $.each(data.response.data, function(key, value)
                        {
                            window.pay_name1 = value.name;
                            window.pay_id1 = value.id;
                            if(pay_name1.toString()=="CASH")
                            {
                                strngg = strngg + "<option value='"+value.id+"' selected>"+value.name+"</option>";
                            }
                            else
                            {
                                strngg = strngg + "<option value='"+value.id+"'>"+value.name+"</option>";
                            }
                            //alert(value.name);
                     });
                                 $('#pay_type').html(strngg);

                });
            }
     }     
        function GetTimeandDatefun(){
                var date = new Date();
		var time = date.toString().substring(0,25) + " IST ";
                $("#timeanddate").html(time);
        }
        $(document).ready(function(){ setInterval(GetTimeandDatefun, 1000);});
	$(document).ready(function() 
		{
			$('ul.nav-pills li.deleteorder').click(function(e) 
			{ 
				if(confirm("Are you sure, You want to delete all items!")) {
					localStorage.clear();
					console.clear();
					printvalue();
			}});
			$('#logout').click(function(){localStorage.clear();});
		});
	  $(function(){
	  	$('#totalamount').click(function(){$('#formtotal').val($('#totalamount').text()); $('#givenamount').val('');$('#tobereturn').val('');$('input:submit').attr('style',  'background-color:#f2f1f0');
          	$('input:submit').attr("disabled",'disabled');});
	        $('#givenamount').keyup(function(){
	        var total = parseInt($('#formtotal').val());
	        var given = parseInt($('#givenamount').val());
	        var change = given - total;
	        $('#tobereturn').val(change); 
	        if(given >= total && total >0)
	        {
	        	$('input:submit').attr("disabled",false);
	            $('input:submit').attr('style',  'background-color:lightgreen');
	        }
	        else{
	        	$('input:submit').attr('style',  'background-color:#f2f1f0');
	          	$('input:submit').attr("disabled",'disabled');
	        }
            });
          var user_name = "";
           var pwd = "";
           var dis = 0;
          var us = "";
          var pass = "";
          var dcount = 0;
          var samIsmanager = "";
          
        /* $('#submitbutton').click(function(){
                var us = $('#user').val();
                var paswd = $('#pass').val();
                var dcount = $('#discount').val();
                   if(us == '' || paswd == ''){
                     alert("Please Enter Username or Password"); 
                   }
                   else if(us != '' || paswd != ''){ 
                   var url_dsct = "<?php echo $POS_URL; ?>ADUser?l="+us+"&p="+paswd+"&_where=username='"+us+"' and samIsmanager=true";
                 alert(url_dsct);
                       
                  $.ajax({
                  url: url_dsct,
                  type: "get",
                  format: "json"
        		  	dataType: "json",
				async: false,
                  success: function(response) {
                  //$.getJSON(url_dsct,function(data) 
                //    {           
                  //    alert(JSON.stringify(data));
                    //  var allowed=data.response.data[0].samDiscountpercentage;
                      //alert(dcount < allowed);
                //});
                  //   alert("Apply Discount of "+dcount+"?");  
                    alert("test");   
                     },
                  error: function(xhr) {
                    console.log(xhr.status);  
                      alert("End test");
                }
                });  
                       
                       
                   }
               else{
                   alert("Invalid Username or Password");  
               }
          });     */ 
          
                     
                
          var duplicate = "";
	        $('#printbutton').click(function(){
                var url_dup = "<?php echo $POS_URL; ?>ADUser?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=username='<?php echo $_SESSION['username'];?>'";
          console.log(url_dup);
                $.getJSON(url_dup,function(data) 
                    {   
                        duplicate = data.response.data[0].samDuplicateprint;
                        alert(duplicate);
                });
                var url = "<?php echo $POS_URL; ?>"+"Order?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>";
	        	var bpid = "<?php echo $_SESSION['bp_id'];?>";
	        	var bploc ="<?php echo $_SESSION['bp_add_id'];?>";
	        	var whereid = "<?php echo $_SESSION['whereid'];?>";
	        	var orgid = "<?php echo $_SESSION['orgid']; ?>";
	        	var doctypeId = "<?php echo $_SESSION['docTypeId'];?>";
			carrybags = $('#carrybags').val();
			carrybags = "No of Bags: " + carrybags ;
                var paymethod = $('#pay_type').val();
                var bptype = $('#cust_type').val();
                var cust_desc = des;
                var custid = $('#cust_type1').val();
                var payterm = pay;
                console.log(pay_terms);
                
	        	var date = new Date();
	        	var datapost = {data:{documentType:doctypeId,transactionDocument:doctypeId,orderReference:cust_desc, description:carrybags, businessPartner: bptype ,currency:"304",paymentMethod:paymethod,paymentTerms:payterm,invoiceTerms:"I",warehouse:whereid,priceList:"979FC3C92AFE47FC96920A83DC56717D",orderDate: date,accountingDate:date,salesTransaction:"true",partnerAddress:bploc,organization:orgid,deliveryLocation:bploc,invoiceAddress:bploc,scheduledDeliveryDate:date}};
	        	console.log(JSON.stringify(datapost));
                
			//alert(JSON.stringify(datapost));
			$.ajax({
	        		type:'POST',
	        		contentType: "application/json;",
	        		url: url,
	        		data: JSON.stringify(datapost),
        		  	dataType: "json",
				async: false,
	        		success: function(createsalesorder){
	        			console.log("Order"+createsalesorder);
	        			if(createsalesorder.response.status == 0 ){
		        			var orderid = createsalesorder.response.data[0].id;
		        			var whereid = "<?php echo $_SESSION['whereid'];?>";
		        			var linenumber = 10;
							var orderData={data:[]};
							var count=1;
							var bpid = "<?php echo $_SESSION['bp_id'];?>";
		        			var bploc = "<?php echo $_SESSION['bp_add_id'];?>";
				        	var orgid1 = "<?php echo $_SESSION['orgid']; ?>";
							var linesurl="<?php echo $POS_URL; ?>OrderLine?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>";
		        			for ( var i = 0, len = localStorage.length; i < len; ++i ) 
					        {
								obj1 = localStorage.getItem( localStorage.key(i)) ;
								obj = JSON.parse(obj1);
								obj1 = localStorage.getItem(localStorage.key(i)) ;
								obj = JSON.parse(obj1);
								let dat = {};
								dat._entityName = "OrderLine";
								dat.salesOrder = orderid;
								dat.orderDate = new Date();
								dat.lineNo = count * 10;
								count++;
								dat.currency = "304";
								dat.unitPrice = obj.Price;
								dat.listPrice = obj.Price;
								dat.grossUnitPrice = obj.Price;
								dat.grossListPrice = obj.Price;
								dat.warehouse = whereid;
								dat.product = obj.Id;
								dat.partnerAddress = bploc;
								dat.businessPartner = bpid;
								dat.orderedQuantity = obj.Quantity;
								dat.uOM = obj.Uom;
								dat.tax = obj.Tax;
								dat.organization = orgid1;
								orderData.data.push(dat);
					      	}
					      		console.log("linesdate -->"+JSON.stringify(orderData));
					      		$.ajax({
				        		type:'POST',
				        		contentType: "application/json;",
				        		url: linesurl,
				        		data: JSON.stringify(orderData),
			        		  	dataType: "json",
							async: false,
			        		  	success: function(response){
			        		  		if(response.response.status == 0){
			        		  			console.log(response);
			        		  			var grnurl = "<?php echo $POS_URL1; ?>ws/com.saksham.uploadfile.processGRNorOrder?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>";
			        		  			var quotData={data:{}};
										quotData.data.MinoutID = "";
										quotData.data.OrderID = response.response.data[0].salesOrder;
										$.ajax({
						        		type:'POST',
						        		contentType: "application/json;",
						        		url: grnurl,
						        		data: JSON.stringify(quotData),
					        		  	dataType: "json",
										async: false,
					        		  	success: function(completion){
					        		  		if(completion.response.message = "Sales Order Invoice Generated Successfully")
					        		  		{
					        		  			alert(completion.response.message);
												var invoiceNumber = completion.response.invoice;
												if(invoiceNumber != '')
												{
													var d = new Date();
													var date = ("0" + d.getDate()).slice(-2) +"/" +("0" + d.getMonth()).slice(-2) +"/"+d.getFullYear();
													var time = ("0" + d.getHours()).slice(-2) +":" +("0" + d.getMinutes()).slice(-2) +":" + ("0" + d.getSeconds()).slice(-2);
													var header21 = "|Bill://"+invoiceNumber+"//UID:  <?php echo $_SESSION['username'];?>|Date://"+date+"//Time: "+time+"|";
													alert("Bill created Successfully with invoice Number:"+invoiceNumber);
													var header1 = $('#header1').text();
													var data = $('#data1').text();
													var data1 = $('#data3').text();
													var productsummary = $('#data2').text();
													var grandtotal = $('#totalgrand').text();
													var taxReceipt = $('#taxReceipt').text();
                                                    var str = "No of Carry Bags: ";
                                                    carrybags = str + $('#carrybags').val();
													console.log(completion);
													var receipt = productsummary + grandtotal + taxReceipt;
													var header2 = header21 + data1;
													var print_receipt = header2 + data + receipt;
                                                    var carry = carrybags;
													$.ajax({
															url: 'http://localhost/karachipos/print.php',
															type: "POST",
															dataType: "json",
															async: false,
															data: ({data: print_receipt,header: header1,bags: carry,dupl: duplicate.toString()}),
															success: function(data){
															},
															error: function(xhr, status, error){
																alert("Collect Print Receipt!");
																localStorage.clear();
												                console.log(jqXHR.status);
																window.location.href="<?php echo $BASE_URL;?>";
																printvalue();
															}
														});
													alert("Collect Print Receipt!");
													localStorage.clear();
									               console.log(jqXHR.status);

													window.location.href="<?php echo $BASE_URL;?>";
													printvalue();
												}
					        		  			else{
					        		  				alert("test"+JSON.stringify(completion.response.message));
					        		  			}
					        		  		}
											else{
												alert("Lines Creation Error :: "+JSON.stringify(completion));
											}
					        		  	},
					        		  	error: function(xhr, status, error){

					        		  		alert("Bill creation Failed!---"+JSON.stringify(error)+JSON.stringify(status)+"---"+JSON.stringify(xhr));
					        		  	}
					        		  });

			        		  		}
			        		  		else{
			        		  			alert("Could not create Lines in ERP, Please contact Administrator."+JSON.stringify(response));
			        		  		}

			        		  	},
			        		  	error: function(xhr, status, error){
			        		  		alert("Could not create Lines in ERP, Please contact Administrator.."+JSON.stringify(error)+"---"+JSON.stringify(status)+"---"+JSON.stringify(xhr));
			        		  	}
			        		  });
					      	}
				      	else{
				      		alert("test2"+JSON.stringify(createsalesorder));
				      	}
	        		},
	        		error: function(xhr, status, error){
	        			alert("Could not create Header in ERP, Please contact Administrator..."+JSON.stringify(xhr)+"---"+JSON.stringify(status)+"---"+JSON.stringify(error));
	        		}
	        	});
	        });
	  });
   
    
	function browseProducts(x){
		var id=x;
		url_prod="<?php echo $POS_URL; ?>GST_Orgproduct_Price_V?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=productCategory=%27"+id+"%27 and organization=%27<?php echo $_SESSION['orgid']; ?>%27 and qtyonhand > 0&_selectedProperties=name,product,qtyonhand";
        //console.log(url_prod);
	$.getJSON(url_prod,function(data) 
    {
    	$('#productsDiv').html('');
      $.each(data.response.data, function(key, value)
      {
      	if(value.name != '')
      	{
            var qvalue = value.qtyonhand;
            //alert(qty);
        console.log(value.name);
        $('#productsDiv').append('<button style="width:100%;min-height:45px;" onclick=additem("'+value.product+'")>'+value.name+' <span class="badge badge-light">'+qvalue+'</span> </button><br>');
    	}});
    });
	}
	$('#pills-browse-tab').click(function(){
		url_prod="<?php echo $POS_URL; ?>ProductCategory?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_selectedProperties=id,name";
		$.getJSON(url_prod,function(data) 
        {
    		$('#categoriesDiv').html('');

          $.each(data.response.data, function(key, value)
          {
          	if(value.name != '')
          	{
            console.log(value.name);
            $('#categoriesDiv').append('<button style="width:100%;height:45px;" onclick=browseProducts("'+value.id+'")>'+value.name+'</button><br>');
        	}});
        });
	});
    
    
    var quantity_value = 0;  
    
    
    function additem(x)
    {
      var output = x;
      if(output!='')
      {
        var url_prod = "<?php echo $POS_URL; ?>GST_Orgproduct_Price_V?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=product='"+output+"' and organization=%27<?php echo $_SESSION['orgid']; ?>%27";
          
          var quantity_prod = "<?php echo $POS_URL; ?>MaterialMgmtStorageDetail?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=product='"+output+"' and organization=%27<?php echo $_SESSION['orgid']; ?>%27";
        console.log(url_prod);
            
        $.getJSON(url_prod,function(data) 
          {
            $.each(data.response.data, function(key, value){
              var name_Prod = value.name;
              var id_Prod = value.product;
              var tax_Prod = value.nonigsttax;
              var uom_Prod = value.uom;
              var price_Prod = value.pricestd;
              var taxrate_Prod = value.nonigsttax$_identifier;
              var taxamount_Prod = value.taxamt;
              var taxratepercent = value.cgst;
              var totaltaxratepercent = value.igst;
	      var hsncode = value.gstproductcode;
                
                
                $.getJSON(quantity_prod,function(data) 
          {
            $.each(data.response.data, function(key, value){
                quantity_value = value.quantityOnHand; 
                

              if (typeof(Storage) !== "undefined") {
                if(localStorage.getItem(id_Prod) === null)
                {
                    if(quantity_value > 0)
                        {
                  var product_Array = {"Name":name_Prod,"Quantity":1,"Id":id_Prod,"Tax":tax_Prod,"Uom":uom_Prod,"Price":price_Prod,"TotalPrice":price_Prod,"Tax_Rate":taxrate_Prod,"Tax_Amount":taxamount_Prod,"TotalTaxAmount":taxamount_Prod,"TaxPercent":taxratepercent,"TotalTaxPercent":totaltaxratepercent,"hsnCode":hsncode};
                  localStorage.setItem(id_Prod,JSON.stringify(product_Array));
                        }
                    else{
                           alert("Product Quantity does not exist!");
                    
                    }

                }
                else 
                {
                  var product_Array = JSON.parse(localStorage.getItem(id_Prod));
                  if(product_Array.Quantity < quantity_value){
                    
                  product_Array.Quantity++;
                  product_Array.TotalPrice = parseInt(product_Array.Quantity) * parseInt(product_Array.Price);
                  product_Array.TotalTaxAmount = product_Array.Tax_Amount * product_Array.Quantity;
                  //alert(array.count);
                  localStorage.setItem(id_Prod,JSON.stringify(product_Array));
                        
                    }
                     else{
                        alert("Product Quantity does not exist!");
                    }
                }
                  
                    
                console.log(localStorage.getItem(id_Prod));
                printvalue();
              }
              else {
                  document.getElementById("orderitems").innerHTML = "Sorry, your browser does not support Web Storage...Please Update your browser to latest version.";
              }
            });
          }); 
                  });
          });
        };
    }
    function removeitem(x)
    {
    	var id=x;
    	localStorage.removeItem(id); 
    	printvalue();
    }
    function decreasecount(x)
    {
    	id_Prod=x;
    	if(localStorage.getItem(id_Prod) === null)
                {
                  alert("No Items to remove");
                }
                else
                {

                  var product_Array = JSON.parse(localStorage.getItem(id_Prod));
                  if(product_Array.Quantity > 1){
                  product_Array.Quantity--;
                  }
                  else{
                  	alert("Quantity cannot be reduced than one! You can remove item by using remove button at the end of the line.");
                  }
                  product_Array.TotalPrice = parseInt(product_Array.Quantity) * parseInt(product_Array.Price);
                  product_Array.TotalTaxAmount = product_Array.Tax_Amount * product_Array.Quantity;
                  //alert(array.count);
                  localStorage.setItem(id_Prod,JSON.stringify(product_Array));
                  console.log(localStorage.getItem(id_Prod));

                }
                printvalue();
    }
    function increasecount(x)
    {
    	id_Prod=x;
       
    	if(localStorage.getItem(id_Prod) === null)
                {
                  alert("No Items to remove");
                }
                else
                {
                  var product_Array = JSON.parse(localStorage.getItem(id_Prod));
                   
                    if(product_Array.Quantity < quantity_value)
                        {
                              product_Array.Quantity++;                               
                              product_Array.TotalPrice = parseInt(product_Array.Quantity) * parseInt(product_Array.Price);
                              product_Array.TotalTaxAmount = product_Array.Tax_Amount * product_Array.Quantity;
                              //alert(array.count);
                              localStorage.setItem(id_Prod,JSON.stringify(product_Array));
                              console.log(localStorage.getItem(id_Prod));
                    
                        }
                    else
                        {
                            
                              $("#plus").attr("disabled", true);
                              //$("#plusid").css('display','none');
                              alert("Maximum Quantity Exhausted!")            
                        }
                 
                }
                printvalue();
    }
    function printvalue(x)
    {
      string = "<table width=100%; ><tr ><th style='width:40%;'>Name</th><th style='width:30%;'>Quantity</th><th style='width:10%;'>Rate</th><th style='width:15%;'>Amount</th><th style='width:5%;'></th></tr><tr><td style='width:50%;'>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
      TotalQuantity = 0;
      TotalPriceItems = 0;
      array=[];
      var line="------------------------------------------|";
      var product_Array = [];
      var data1 = line+"Description//Rate//Qty//Amount|[HSN //CGST%//Value//SGST%//Value]|"+line;
      var addr = "<?php echo $_SESSION['storeaddr'];?>";
      var gstid = "GSTIN : <?php echo $_SESSION['tax_id'];?>";
	  var data = "";
      var header1 = addr+"|" +gstid +"|"//+"------------------------------------------";
      
      var tax = {};
      for ( var i = 0, len = localStorage.length; i < len; ++i ) 
        {
          obj1 = localStorage.getItem( localStorage.key(i)) ;
          obj = JSON.parse(obj1);
          var prodid = String(obj.Id);
          var tax_key = String(obj.Tax);
          string = string + "<tr><td style='width:40%;'>"+obj.Name+"</td><td style='width:30%;'>"+'<button class="btn  btn-xs btn-primary btn-circle"  onclick="decreasecount('+"'"+prodid+"'"+')" ><i class="fa fa-minus"></i></button><label style="width:35px;text-align:center;size:18px;padding-left:8px;" >'+obj.Quantity+'</label><button id="plus" type="submit" class="btn btn-xs btn-primary btn-circle" onclick="increasecount('+"'"+prodid+"'"+')" ><i id="plusid" class="fa fa-plus"></i></button></td><td style="width:11%;padding-right:15px;">'+obj.Price+"</td><td style='width:14%;text-align:right;padding-right:15px;'>"+obj.TotalPrice+"</td><td style='width:5%;'>"+'<button class="btn  btn-xs btn-danger btn-circle"  onclick="removeitem('+"'"+prodid+"'"+')" ><i class="fa fa-close"></i></button></td></tr>';
          TotalQuantity = TotalQuantity + parseInt(obj.Quantity);
          TotalPriceItems = TotalPriceItems + parseInt(obj.TotalPrice);
          data = data + obj.Name.substring(0,15)+"//"+Math.round(obj.Price)*100/100+"//"+obj.Quantity+"//"+ parseInt(obj.TotalPrice) +"|["+ obj.hsnCode.substring(0,8) +"  "+Math.round(obj.TaxPercent * 100) / 100+"//"+Math.round((obj.TotalTaxAmount/2) * 100) / 100 +"//"+ Math.round(obj.TaxPercent * 100) / 100+"//"+Math.round((obj.TotalTaxAmount/2) * 100) / 100  + "]|";
          var tax_key = String(obj.Tax);
          var taxReceipt = "GST/Tax Desc. // Sales(Incl.)//GST/Tax|";
          if(tax.hasOwnProperty(tax_key))
          {
          	tax[tax_key].amount = tax[tax_key].amount + Math.round(parseFloat(obj.TotalTaxAmount) * 100)/100;
          	tax[tax_key].withtaxamount=tax[tax_key].withtaxamount + TotalPriceItems;
          	console.log(tax[tax_key].amount);
          }
          else
          {
          	tax[tax_key]={};
          	tax[tax_key].name=obj.Tax_Rate;
          	tax[tax_key].taxpercent=obj.TotalTaxPercent;
          	tax[tax_key].amount=Math.round(parseFloat(obj.TotalTaxAmount) * 100)/100;
          	tax[tax_key].withtaxamount=TotalPriceItems;
          	console.log(tax[tax_key].name+"br"+JSON.stringify(tax));
          }}
        data = data;
        var productSummary = line+"Items/Qty :// // //"+localStorage.length+"/"+TotalQuantity+"|Sub Total :// //Rs.//"+TotalPriceItems+"|";
        var grandtotal = "Total     ://  //Rs. //"+TotalPriceItems+"|"+line;
        $('#header1').text(header1);
        $('#data1').text(data);
		$('#data3').text(data1);
		$('#data2').text(productSummary);
        $('#totalgrand').text(grandtotal);
        string = string + "<tr><td 'width:40%;'>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><th 'width:50%;'>Total</th><th style='padding-left:35px;'>"+TotalQuantity+"</th><th>&nbsp;</th><th style='text-align:right;padding-right:15px;'>"+TotalPriceItems+"</th><th></th></tr></table>";
        string_tax = "<table width=100%;><tr><th style='width:20%;'></th><th  style='width:20%;'></th><th style='text-align:right;padding-right:15px;width:30%;'>Tax Type</th><th style='text-align:right;padding-right:15px;width:30%;'>Tax Amount</th></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>";
       	var AllTaxesTotal = 0;
        	for(var s =0; s < Object.keys(tax).length; s++)
        	{
        		string_tax = string_tax + "<tr><td style='width:25%;'></td><td style='width:25%;'></td><td style='text-align:right;padding-right:15px;'>"+ tax[Object.keys(tax)[s]].name.split("+")[0] + "</td><td style='text-align:right;padding-right:15px;'>" + Math.round(((tax[Object.keys(tax)[s]].amount)/2)* 100) / 100 + "</td><td><tr><td style='width:25%;'></td><td style='width:25%;text-align:right;padding-right:15px;'></td><td style='text-align:right;padding-right:15px;'>"+ tax[Object.keys(tax)[s]].name.split("+")[1] + "</td><td style='text-align:right;padding-right:15px;'>" + Math.round(((tax[Object.keys(tax)[s]].amount)/2)* 100) / 100 +"</td><td>";
        		AllTaxesTotal = AllTaxesTotal + tax[Object.keys(tax)[s]].amount;
        		taxReceipt = taxReceipt + "GST/Tax @ "+tax[Object.keys(tax)[s]].taxpercent+"%// //"+tax[Object.keys(tax)[s]].withtaxamount+"//"+tax[Object.keys(tax)[s]].amount+"|[ "+tax[Object.keys(tax)[s]].name.split("+")[0] +  Math.round(((tax[Object.keys(tax)[s]].amount)/2)* 100) / 100 +" ]  [ "+tax[Object.keys(tax)[s]].name.split("+")[1] +" " + Math.round(((tax[Object.keys(tax)[s]].amount)/2)* 100) / 100 +" ]";
        	}
        	taxReceipt = taxReceipt;
        	$('#taxReceipt').text(taxReceipt);
		string_tax = string_tax + "<tr><td style='width:20%;'>&nbsp</td><td style='width:20%;'>&nbsp</td><td>&nbsp</td><td>&nbsp;</td><tr><th style='width:20%;'></th><th  style='width:20%;'></th><th style='text-align:center;width:30%;'>Tax Total</th><th style='width:30%;text-align:right;padding-right:15px;'> "+ Math.round(((AllTaxesTotal))* 1000) / 1000 + "</th></tr></table>";       
        document.getElementById("orderitems").innerHTML=string;
        document.getElementById("totalamount").innerHTML=TotalPriceItems;
        document.getElementById("taxes").innerHTML=string_tax;
        $('#array').text(data);
    }
function change(x){
    console.log("Entered into change Fun!");
    var empty = false;
    $('.barcode_search input').each(function() 
    {
      if ($(this).val().length == 0) {empty = true;}
    });
    if(empty) 
      {
        $('.list ul').hide();
        console.log("No list elements");
      }
    else
      {
        if($('.list ul').show()){var id = x;if (id != ''){console.log(id);additem(id);}
          setTimeout(function(){$('.barcode_search input').val('')},300);$('result').html('');}}
      }
$(function()
  {
    $.ajaxSetup({ cache: false });
    $('#barcode_search').keyup(function()
    {
      $('#barcode-result').html('');
      $('#state').val('');
      var searchField = $('#barcode_search').val();
      var expression=new RegExp(searchField, "i");
      var url_prod = '<?php echo $POS_URL; ?>GST_Product_Price_V?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_selectedProperties=name,product,pricestd,upc';
      $.getJSON(url_prod,function(data) 
        {
          $.each(data.response.data, function(key, value)
          {
            if (value.upc == searchField)
            {
              $('#result').append('<li class="list-group-item link-class" data-original-index="'+ key +'" >' +value.name+' | <label class="text-success" style="text-align:right;padding:5px 10px;text-decoration:underline;">'+value.pricestd+'.00 /-</label><span style="display:none;">'+value.product+'| </span></li>');
                change(value.product);
            }});});});
      console.log($("#result li").text());
      $('#result').on('click', 'li', function() 
        {
          var click_text = $(this).text().split('|');
          $('barcode_search').val($.trim(click_text[0]));
          $("#result").html('');
        });});
$('#scanitem').click(function(){$(".barcode_search input").focus();});
$(document).ready(function(){
 $.ajaxSetup({ cache: false });
 $('#product_search').keyup(function(){
  $('#product-result').html('');
  $('#state').val('');
  var searchField1 = $('#product_search').val();
  var expression1 = new RegExp(searchField1, "i");
  var url_prod1 = '<?php echo $POS_URL; ?>GST_Orgproduct_Price_V?l=<?php echo $_SESSION['username'];?>&p=<?php echo $_SESSION['password'];?>&_where=qtyonhand>0&_selectedProperties=name,value,product,pricestd,upc';
     //console.log(url_prod1);
  $.getJSON(url_prod1, function(data) {
  $("#product-result").html('');
   $.each(data.response.data, function(key, value){
    if (value.name.search(expression1) != -1 || value.value.search(expression1) != -1)
    {
     $('#product-result').append('<li onclick=additem("'+value.product+'") class="list-group-item link-class" data-original-index="'+ key +'" >' +value.value+' | '+value.name+' | <label class="text-success" style="text-align:right;padding:5px 10px;text-decoration:underline;">'+value.pricestd+'.00 /-</label><span style="display:none;">'+value.product+'| </span></li>');
    	 console.log(value.product + value.name)
    }});});});
 $('#product-result').on('click', 'li', function() {
  var click_text = $(this).text().split('|');
  $('#product_search').val($.trim(click_text[0]));
  setTimeout(function(){  $('#product_search').val('');
  $('#product_search').focus();
},2000);
  $("#product-result").html('');
 });});

//Day End Summary
var printData = "";var tax="";var user="<?php echo $_SESSION['username']; ?>";var password="<?php echo $_SESSION['password']; ?>";
var url_Dayend ="<?php echo $POS_URL; ?>GST_Dayend_Details_V?l="+user+"&p="+password+"&_selectedProperties=invcnt,invdate,invincltaxamt,invexcltaxamt,taxamt,itemssold,startinvnum,endinvnum,voidinvcnt,voidinvamt&_where=organization=%27<?php echo $_SESSION['orgid']; ?>%27and%20Date(invDate)=Date('now()')";
var url_gst = "<?php echo $POS_URL; ?>GST_Dayend_Tax_V?l=Openbravo&p=s&_where=organization=%27<?php echo $_SESSION['orgid']; ?>%27and Date(invDate)=Date(%27now()%27)";
//alert(url_Dayend);

		$.getJSON(url_Dayend,function(data) 
		 {
					$.each(data.response.data, function(key, value)
					 {
	printData = printData + "Sales  (Inc.Tax) //    Rs.//   "+Math.round(value.invincltaxamt)*100/100+"|Net Sales(Exc. Tax) //    Rs.//   "+value.invexcltaxamt+"|Net Sales(Inc. Tax)//    Rs.//   "+value.invincltaxamt+"|Tax//////    Rs.//   "+value.taxamt+"|Cess//////    Rs.//   0.00"+"|Service Charge////    Rs.//   0.00"+"|Other Charge////    Rs.//   0.00|"+"Tot Sales Collection //    Rs.//   "+value.invincltaxamt+"|Deposit Collected     //    Rs.//   0.00|"+"Deposit Refunded   (-)//    Rs.//   0.00|"+"Deposit Forefeited (-)//    Rs.//   0.00|"+"Deposit Utilised   (-)//    Rs.//   0.00"+"|AdvanceCollected   (+)//    Rs.//   0.00|"+"Utilised Amount    (-)//    Rs.//   0.00|"+"TOTAL Amount Collected //    Rs.//   "+value.invincltaxamt+"||No. of Items Sold////   "+value.itemssold+"|No. of void Invoices////   "+value.voidinvcnt+"|No Of No-Sale Done////   0|"+"No Of Price Overrides////   0"+"|"+"No Of Lines Disc.////   0"+"|"+"No Of Customers//////   0"+"|"+"No Of Deposit Collected////   0"+"|"+"No Of Deposit Refunded////   0"+"|"+"No Of Deposit Forfeited////   0"+"|"+"No Of Deposit Utilised////   0"+"|"+"No Of Customer Enquiery////   0"+"|"+"No Of SKU Enquiery////   0"+"|"+"Amt. of void Invoices////   "+value.voidinvamt+
	"||Sales Receipts//"+value.startinvnum.split("-")[0]+"-"+value.startinvnum.split("-")[1]+"-["+value.startinvnum.split("-")[value.startinvnum.split("-").length-1]+"-"+value.endinvnum.split("-")[value.endinvnum.split("-").length-1]+"]   "+value.invcnt+"||"+"Refund////"+"0"+"//"+"Rs. //   "+"0.00|"+"Cancellation //"+"0"+"//"+"Rs. //   "+"0.00"+"|"+"|------------------------------------------|CASH // // //Rs. //   "+value.invincltaxamt+"|***Total CASH // //Rs. //   "+value.invincltaxamt+"|------------------------------------------|";
						 $("#receipt").text(printData);
					 });
				var a = $("#receipt").text();
				tax= tax+a+"Percentage//"+"Tax Amount   "+"Bill Amount|"+"|";
				$.getJSON(url_gst,function(data) 
				{
					$.each(data.response.data, function(key, value)
					{
						var valuetaxbaseamt1=value.tax+value.taxbaseamt;
						tax = tax+value.taxgroup+"////"+value.tax+"////"+valuetaxbaseamt1+"|";
					});
				});
	 });
$('#printbutton2').click(function()
	{
		tax=tax+"|------------------------------------------|";
		var  addr=new Date().toLocaleString();
		var header1 = addr+"  User:"+"<?php echo $_SESSION['username']; ?>"+"|"+"Z-Readings Report"+"|" +"MODE :END-DAY|"+"------------------------------------------";	
	$.ajax({
		url: 'http://localhost/karachipos/print.php',
		type: "POST",
		dataType: "json",
		async: false,
		data: ({data: tax,header :header1}),
		success: function(data)
		{
			alert("success");
		},
		error: function(xhr, status, error)
		{
		}
	});
});
</script>
