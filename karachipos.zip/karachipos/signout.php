<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
	
	localStorage.clear();

</script>
</head>
<body>

</body>
</html>



<?php
if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
		$uri = 'https://';
	} else {
		$uri = 'http://';
	}
	$uri .= $_SERVER['HTTP_HOST'];
	$BASE_URL = $uri . "/karachipos/";
if (session_status() == PHP_SESSION_NONE) 
	{
    	session_start();
	}
if(empty($_SESSION['username']))
	{
		header("Location:".$BASE_URL);
	}
unset($_SESSION['username']);
unset($_SESSION['password']);
session_destroy();
header( "Location: ".$BASE_URL ); 
//echo "Successfully Logout";
exit;
?>