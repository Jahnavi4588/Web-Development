<?php
include "./header.php";
if(empty($_SESSION['username']))
	{
		header("Location:".$BASE_URL);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.panel-heading,.panel-body{
			width:100%;
		}
		#invoices,#bootstrap-iso{
			width:60%;
			margin:auto;
			min-width: 650px;
			max-width: 700px;
		}
		#headingOne > label,#headingOne1 > label{
			width: 25%;
		}
		body{
			font-size: 12px;
		}
		ul{
			list-style: none;
		}
	</style>
</head>
<body>
	<div class="bootstrap-iso" id="bootstrap-iso">
		<div class="container-fluid"><br>
			<div class="row" style="border:1px solid #ddd;">
				<div class="col-md-11 col-sm-11 col-xs-11 col-md-offset-1 col-sm-offset-1 col-xs-offset-1" >
						<div class="form-group"><br>
							<div class="row">
							<center>
								<input class="form-control" id="date" name="date1" placeholder="Start Date" type="text" style="width:30%;float:left;margin-right: 15px;"/>
								<input class="form-control" id="date1" name="date2" placeholder="End Date" type="text" style="width:30%;float:left;margin-right: 15px;" />
								<button class="btn btn-primary " id="submit" name="submit" type="submit" style="float:left;margin-right: 15px;">Submit</button>
								<a href="<?php echo $BASE_URL; ?>" style="float:left;"><button class="btn btn-success">POS HOME</button></a>
							</center>
							</div>
						</div>
						<div id="datemessage" ><center><h5>Select dates to get invoices.</h5></center></div>
				</div>
			</div>    
		</div>
	</div>
	<div id="invoices" class="fancy-collapse-panel">
		<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
			<div class="panel panel-default">
				<div style="background-color: #f5f5f5;margin-top:5px; margin-bottom:5px;font-size: 14px;" class="panel-heading" role="tab" id="headingOne1">
						<label style="width: 4%">#</label>
						<label style="width: 18%">Date</label>
						<label>Inv.No</label>
						<label>Customer</label>
						<label>Amount</label>
					</div>
				<div id="panelcontent"></div><br>
			</div>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
$(document).ready(function()
	{
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		var options={
			format: 'yyyy-mm-dd',
			container: container,
			todayHighlight: true,
			autoclose: true,
		};
		$('input').datepicker(options);
	});
$('#submit').click(function(){
	$('#datemessage').html('<center> Invoices from &nbsp;<label><u><p id="text"></p></u></label>&nbsp; to &nbsp;<label><u><span id="text2"></span></u></label></center>');
	var string="<div class='panel panel-default'>";
	var count=0;
	var total=0;
	var m = document.getElementById("date").value;
	var n= document.getElementById("date1").value;
	document.getElementById("text").innerHTML = m;
	document.getElementById("text2").innerHTML = n;
	var user="<?php echo $_SESSION['username']?>";
	var password="<?php echo $_SESSION['password'];?>";
	var org="<?php echo $_SESSION['orgid'];?>";
	var url_prod ="<?php echo $POS_URL; ?>"+"Invoice?l="+user+"&p="+password+"&_selectedProperties=invoiceDate,documentNo,businessPartner,creationDate,grandTotalAmount,id,organization"+"&_sortBy=documentNo asc&_where=organization=%27"+org+"%27%20and%20Date(creationDate)%20%3E=%20Date(%27"+m+"%27)%20and%20Date(creationDate)%20%3C=%20Date(%27"+n+"%27)";
	$.getJSON(url_prod,function(data) 
		{
			$.each(data.response.data, function(key, v)
			{
				if(v.grandTotalAmount >0)
				{
					count=count+1;
					total = total + v.grandTotalAmount ;
					string=string+"<div><a class='collapsed' data-toggle='collapse' "+"data-parent='#accordion' href='#collapse"+count+"' aria-expanded='true' aria-controls='collapse"+count+"'><div style='background-color: #f5f5f5;"+"margin-bottom:5px;' class='panel-heading' role='tab' "+"id='headingOne'>"+"<label style='width: 4%'>"+count+"</label><label style='width: 18%'>"+v.creationDate.substring(0,10)+"</label><label>"+v.documentNo+"</label><label>"+v.businessPartner$_identifier+"</label><label>"+v.grandTotalAmount.toFixed(2)+"</label><span class='glyphicon glyphicon-menu-down'></span>"+"</div></a></div>";
					var url2 = "<?php echo $POS_URL; ?>"+"InvoiceLine?l="+user+"&p="+password+ "&_where=invoice=%27"+v.id+"%27&_selectedProperties="+"invoice,product,grossListPrice,grossAmount,invoicedQuantity";
					string = string +"<div id='collapse"+count+"' data-parent='#accordion' class='panel-collapse collapse' role='tabpanel' aria-labelledby='headingOne' aria-expanded='false' aria-controls='collapse"+count+"'><div class='panel-body'>"+"<ul id='"+v.id+"' style='width:95%;'><li style='margin-top:5px;'>"+"<label style='width: 50%;border-bottom:1px dotted black;'>Product</label><label style='width: 15%;border-bottom:1px dotted black;'>Rate</label><label style='width: 15%;border-bottom:1px dotted black;text-align:center;'>"+"Quantity</label><label style='width: 15%;border-bottom:1px dotted black;text-align:right;'>Amount</label></li> <li> &nbsp; </li>";
					if(string!='')
					{
						$.getJSON(url2,function(obj) 
						{
							$.each(obj.response.data, function(n,e)
							{
								if(e.product$_identifier!='')
								{
									var id='#'+e.invoice;
									$(id).append("<li><label style='width: 50%'>"+e.product$_identifier+"</label><label style='width: 15%'>"+e.grossListPrice+"</label><label style='width: 15%;text-align:center;'>"+e.invoicedQuantity+"</label><label style='width: 15%;text-align:right;'>"+e.grossAmount+"</label></li>");
								}
							});
						});
						string=string+"</ul></div></div>";
					}
				}
					string=string+"</div>";
			});
			string = string + '<div style="background-color: #f5f5f5;margin-top:5px;margin-bottom:5px;font-size: 14px;" class="panel-heading" role="tab" id="headingOne1"><label style="width: 4%"></label><label style="width: 18%"></label><label></label><label style="text-align:right;padding-right:10px;"><u>Total:</u> </label><label style="padding-left:10px;"><u> '+total+'</u> </label></div>';
			document.getElementById("panelcontent").innerHTML=string;
		});
});
</script>
