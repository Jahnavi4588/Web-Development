<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Modal 1</h2>
  <!-- Button to Open the Modal -->
   <li class="nav-item" style="width: 14%;margin-left: 2%;">
					       <a class="nav-link TotalPrice" data-toggle="pill" href="#pills-last" role="tab" aria-controls="pills-last" aria-selected="true" style="height:60px;"><div data-toggle="modal" data-target="#myModal" id="totaldiscount">0.00</div></a>
					    </li> 
  

  <!-- The Modal1 -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">change</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form action="#" method="POST">
                                 <label id="pa" style="width: 200px">Payment:</label>
                                 <select id="pay_type" style="width: 200px;" selected='selected' onchange="paytype(this)">            </select>								
					            <label style="width: 200px;">Total:</label><input type="text" disabled=disabled id="formtotal" style="width: 200px;"><br>
					            <label style="width: 200px;">Amount Given:</label><input type="text" id="givenamount" value="" style="width: 200px;"><br>
					            <label style="width: 200px;">Need to be returned:</label><input type="text" value="" disabled=disabled id="tobereturn" style="width: 200px;"><br>
						    <label style="width: 200px;">No. of carry bags :</label><input type="text" id="carrybags" name="carrybags" value="1" style="width: 200px;"><br><br>
					            <input style="margin-right:50px;background-color: #6cb33f;color:black;" type="submit" value="Print" id="printbutton"><br>
					          </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  
  <h2>Modal 2</h2>
  <!-- Button to Open the Modal -->
  <li class="nav-item" style="width: 14%;margin-left: 2%;">
					       <a class="nav-link TotalPrice" data-toggle="pill" href="#pills-last" role="tab" aria-controls="pills-last" aria-selected="true" style="height:60px;"><div data-toggle="modal" data-target="#myModal1" id="totaldiscount">Discount</div></a>
					    </li>  
  

  <!-- The Modal -->
  <div class="modal" id="myModal1">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Discount</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <form action="#" method="POST">
                                  
                                <p>Some text in the popup.</p>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
</div>  
</div>
</body>
</html>
    
     /* alert(us);
                   alert(paswd);
                   alert(dcount);
                   if(us == '' || paswd == ''){}
                   else{
                    alert("InFun: "+us); 
                   var url_dst = "<?php echo $POS_URL; ?>ADUser?l="+us+"&p="+paswd+"&_where=username='"+us+"'";
                    //alert(url_dst);
                $.getJSON(url_dst,function(data) 
                  {            
                    
                    $.each(data.response.data, function(key, value){
                       samIsmanager = value.samIsmanager;
                        alert(samIsmanager);
                          });
                });*/
